package com.livescore.floating

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/** Tiny in-memory logo loader (no third-party library). */
object ImageLoader {
    private val cache = object : LruCache<String, Bitmap>(8 * 1024) { // ~8 MB
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    suspend fun load(url: String): Bitmap? {
        if (url.isBlank()) return null
        cache.get(url)?.let { return it }
        return withContext(Dispatchers.IO) {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 8000
                val bmp = c.inputStream.use { BitmapFactory.decodeStream(it) }
                c.disconnect()
                if (bmp == null) null else {
                    val s = if (bmp.width > 160) {
                        Bitmap.createScaledBitmap(
                            bmp, 160, (160f * bmp.height / bmp.width).toInt().coerceAtLeast(1), true
                        )
                    } else bmp
                    cache.put(url, s)
                    s
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
        }
    }
}
