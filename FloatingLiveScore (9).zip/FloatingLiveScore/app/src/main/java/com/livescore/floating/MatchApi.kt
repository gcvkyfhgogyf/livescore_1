package com.livescore.floating

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Uses API-Football (api-sports.io). Blank key -> built-in demo data. */
object MatchApi {
    private const val BASE = "https://v3.football.api-sports.io/fixtures"

    suspend fun fetchLive(apiKey: String): List<Match> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) DemoData.matches() else parse(httpGet("$BASE?live=all", apiKey))
    }

    /** All of today's matches (upcoming, live, finished) in the phone's time zone. */
    suspend fun fetchToday(apiKey: String): List<Match> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext DemoData.today()
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val tz = URLEncoder.encode(TimeZone.getDefault().id, "UTF-8")
        parse(httpGet("$BASE?date=$d&timezone=$tz", apiKey)).sortedBy { it.kickoff }
    }

    private fun httpGet(url: String, key: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.setRequestProperty("x-apisports-key", key)
            conn.connectTimeout = 10_000
            conn.readTimeout = 15_000
            if (conn.responseCode != 200) error("Server error ${conn.responseCode}")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun parse(body: String): List<Match> {
        val root = JSONObject(body)
        val errs = root.optJSONObject("errors")
        if (errs != null && errs.length() > 0) {
            error(errs.optString(errs.keys().next(), "API error"))
        }
        val arr = root.optJSONArray("response") ?: return emptyList()
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val fx = o.getJSONObject("fixture")
            val st = fx.getJSONObject("status")
            val teams = o.getJSONObject("teams")
            val goals = o.getJSONObject("goals")
            val home = teams.getJSONObject("home")
            val away = teams.getJSONObject("away")
            val evArr = o.optJSONArray("events")
            val events = if (evArr == null) emptyList() else (0 until evArr.length()).map { j ->
                val e = evArr.getJSONObject(j)
                MatchEvent(
                    minute = e.optJSONObject("time")?.optInt("elapsed") ?: 0,
                    type = e.optString("type"),
                    detail = e.optString("detail"),
                    team = e.optJSONObject("team")?.optString("name") ?: "",
                    player = e.optJSONObject("player")?.optString("name") ?: ""
                )
            }
            Match(
                id = fx.getInt("id"),
                league = o.getJSONObject("league").optString("name"),
                home = home.optString("name"),
                away = away.optString("name"),
                homeScore = goals.optInt("home", 0),
                awayScore = goals.optInt("away", 0),
                minute = if (st.isNull("elapsed")) null else st.getInt("elapsed"),
                status = st.optString("short"),
                events = events,
                homeLogo = home.optString("logo"),
                awayLogo = away.optString("logo"),
                kickoff = fx.optLong("timestamp", 0L)
            )
        }
    }
}

/** Stateless simulated matches so the app and widget can be tried without an API key. */
object DemoData {
    private fun logo(id: Int) = "https://media.api-sports.io/football/teams/$id.png"

    private class Spec(
        val id: Int, val league: String, val home: String, val away: String,
        val homeId: Int, val awayId: Int,
        val homeGoals: List<Int>, val awayGoals: List<Int>, val offset: Int
    )

    private val specs = listOf(
        Spec(1, "Premier League", "Arsenal", "Chelsea", 42, 49, listOf(12, 55), listOf(38), 0),
        Spec(2, "La Liga", "Barcelona", "Real Madrid", 529, 541, listOf(23, 71, 80), listOf(44, 66), 20),
        Spec(3, "Serie A", "Inter", "Juventus", 505, 496, emptyList(), listOf(61), 45),
        Spec(4, "Bundesliga", "Bayern", "Dortmund", 157, 165, listOf(8, 33, 59), emptyList(), 70)
    )
    private val players = listOf("Silva", "Rodri", "Haaland", "Saka", "Lewa", "Vini", "Kane", "Lautaro")

    fun matches(): List<Match> {
        val tick = System.currentTimeMillis() / 3000 // 3 real seconds = 1 match minute
        return specs.map { s ->
            val t = ((tick + s.offset) % 110).toInt()
            val (status, m) = when {
                t < 45 -> "1H" to t + 1
                t < 50 -> "HT" to 45
                t < 95 -> "2H" to t - 50 + 46
                else -> "FT" to 90
            }
            val events = mutableListOf<MatchEvent>()
            s.homeGoals.filter { it <= m }.forEach {
                events += MatchEvent(it, "Goal", "Normal Goal", s.home, players[(it + s.id) % players.size])
            }
            s.awayGoals.filter { it <= m }.forEach {
                events += MatchEvent(it, "Goal", "Normal Goal", s.away, players[(it + s.id + 3) % players.size])
            }
            if (m >= 30) events += MatchEvent(30, "Card", "Yellow Card", s.away, players[s.id])
            events.sortBy { it.minute }
            Match(
                id = s.id, league = s.league, home = s.home, away = s.away,
                homeScore = s.homeGoals.count { it <= m },
                awayScore = s.awayGoals.count { it <= m },
                minute = m, status = status, events = events,
                homeLogo = logo(s.homeId), awayLogo = logo(s.awayId)
            )
        }
    }

    fun today(): List<Match> {
        val now = System.currentTimeMillis() / 1000
        fun up(id: Int, lg: String, h: String, a: String, hid: Int, aid: Int, inMin: Int) = Match(
            id, lg, h, a, 0, 0, null, "NS", emptyList(), logo(hid), logo(aid), now + inMin * 60L
        )
        return listOf(
            up(101, "Premier League", "Liverpool", "Man City", 40, 50, 130),
            up(102, "Ligue 1", "PSG", "Marseille", 85, 81, 200),
            up(103, "La Liga", "Atletico", "Sevilla", 530, 536, 320)
        )
    }
}
