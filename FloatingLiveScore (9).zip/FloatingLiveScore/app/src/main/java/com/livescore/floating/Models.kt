package com.livescore.floating

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class MatchEvent(
    val minute: Int,
    val type: String,
    val detail: String,
    val team: String,
    val player: String
) {
    val isGoal: Boolean get() = type.equals("Goal", true)
    val isCard: Boolean get() = type.equals("Card", true)
    val icon: String
        get() = when {
            isGoal -> "⚽"
            isCard && detail.contains("Red", true) -> "🟥"
            isCard -> "🟨"
            type.equals("subst", true) -> "🔄"
            else -> "•"
        }
}

data class Match(
    val id: Int,
    val league: String,
    val home: String,
    val away: String,
    val homeScore: Int,
    val awayScore: Int,
    val minute: Int?,
    val status: String,
    val events: List<MatchEvent>,
    val homeLogo: String = "",
    val awayLogo: String = "",
    val kickoff: Long = 0L // epoch seconds
) {
    val isLive: Boolean get() = status in setOf("1H", "2H", "ET", "P", "LIVE")
    val isUpcoming: Boolean get() = status in setOf("NS", "TBD")

    val clock: String
        get() = when (status) {
            "HT" -> "HT"
            "FT", "AET", "PEN" -> "FT"
            "BT" -> "BT"
            "NS", "TBD" -> "Upcoming"
            else -> if (minute != null) "$minute'" else status
        }

    val timeText: String
        get() = if (kickoff > 0)
            SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date(kickoff * 1000)) else "--:--"

    val dateText: String
        get() = if (kickoff > 0)
            SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH).format(Date(kickoff * 1000)) else ""

    fun startsIn(): String {
        if (kickoff <= 0) return "Upcoming"
        val mins = ((kickoff * 1000 - System.currentTimeMillis()) / 60000).toInt()
        return when {
            mins <= 0 -> "Starting soon"
            mins < 60 -> "Starts in $mins min"
            else -> {
                val h = mins / 60
                if (h == 1) "Starts in 1 hour" else "Starts in $h hours"
            }
        }
    }
}
