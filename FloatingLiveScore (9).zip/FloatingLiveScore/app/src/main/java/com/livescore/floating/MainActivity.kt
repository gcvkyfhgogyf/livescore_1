@file:OptIn(ExperimentalMaterial3Api::class)

package com.livescore.floating

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Orange = Color(0xFFFF8A2A)
private val OrangeBrush = Brush.linearGradient(listOf(Color(0xFFFF8A2A), Color(0xFFE53935)))

class MainActivity : ComponentActivity() {

    private var pendingStart = false

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        val prefs = Prefs(this)
        setContent {
            var theme by remember { mutableIntStateOf(prefs.theme) }
            AppTheme(theme) {
                val running by OverlayService.running.collectAsState()
                App(
                    prefs = prefs,
                    running = running,
                    onToggle = { setOverlay(it) },
                    theme = theme,
                    onTheme = { theme = it; prefs.theme = it }
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        MatchStore.start(this)
    }

    override fun onStop() {
        MatchStore.stop()
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        if (pendingStart && Settings.canDrawOverlays(this)) OverlayService.start(this)
        pendingStart = false
    }

    private fun setOverlay(on: Boolean) {
        if (!on) {
            OverlayService.stop(this)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            pendingStart = true
            Toast.makeText(this, "Allow “Display over other apps” for this app", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        OverlayService.start(this)
    }
}

// ------------------------------------------------------------------ theme

@Composable
fun AppTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val scheme = if (dark) darkColorScheme(
        primary = Orange, onPrimary = Color.Black,
        background = Color(0xFF0A101C), onBackground = Color.White,
        surface = Color(0xFF111A2E), onSurface = Color.White,
        surfaceVariant = Color(0xFF1B2745), onSurfaceVariant = Color(0xFFA9B8D6),
        secondaryContainer = Color(0xFF3A2410), onSecondaryContainer = Orange,
        outline = Color(0xFF5B6B8C)
    ) else lightColorScheme(
        primary = Color(0xFFE86F00), onPrimary = Color.White,
        background = Color(0xFFF2F4F9), surface = Color.White,
        surfaceVariant = Color(0xFFE6EAF3),
        secondaryContainer = Color(0xFFFFE3CC), onSecondaryContainer = Color(0xFFB45300)
    )
    MaterialTheme(colorScheme = scheme) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background, content = content)
    }
}

// ------------------------------------------------------------------ app

@Composable
fun App(
    prefs: Prefs,
    running: Boolean,
    onToggle: (Boolean) -> Unit,
    theme: Int,
    onTheme: (Int) -> Unit
) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var listTab by rememberSaveable { mutableIntStateOf(0) }
    var apiKey by remember { mutableStateOf(prefs.apiKey) }
    val loading by MatchStore.loading.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(if (tab == 0) "Live Scores" else "Settings", fontWeight = FontWeight.ExtraBold)
                },
                actions = {
                    if (tab == 0) IconButton(onClick = {
                        MatchStore.refresh()
                        if (listTab == 1) MatchStore.loadToday(true)
                    }) {
                        Icon(
                            Icons.Filled.Refresh, "Refresh", tint = Orange,
                            modifier = Modifier.alpha(if (loading) 0.4f else 1f)
                        )
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Filled.Home, null) }, label = { Text("Live") }
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Filled.Settings, null) }, label = { Text("Settings") }
                )
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            if (tab == 0) LiveScreen(running, onToggle, apiKey.isNotBlank(), listTab) { listTab = it }
            else SettingsScreen(prefs, theme, onTheme, apiKey) { apiKey = it }
        }
    }
}

@Composable
fun LiveScreen(
    running: Boolean,
    onToggle: (Boolean) -> Unit,
    hasKey: Boolean,
    listTab: Int,
    onListTab: (Int) -> Unit
) {
    val live by MatchStore.matches.collectAsState()
    val today by MatchStore.today.collectAsState()
    val pinned by MatchStore.pinnedId.collectAsState()
    val err by MatchStore.error.collectAsState()

    LaunchedEffect(listTab) { if (listTab == 1) MatchStore.loadToday() }

    val list = if (listTab == 0) live else today

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { WidgetCard(running, onToggle) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilterChip(
                    selected = listTab == 0, onClick = { onListTab(0) },
                    label = { Text("Live (${live.size})", fontWeight = FontWeight.Bold) }
                )
                FilterChip(
                    selected = listTab == 1, onClick = { onListTab(1) },
                    label = { Text("Today (${today.size})", fontWeight = FontWeight.Bold) }
                )
            }
        }
        if (!hasKey) item {
            Text(
                "Demo mode: simulated matches. Add your API key in Settings for real scores.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        err?.let { msg ->
            item { Text("⚠ $msg", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
        }
        if (list.isEmpty()) item {
            Text(
                if (listTab == 0) "No live matches right now." else "No matches loaded yet.",
                modifier = Modifier.fillMaxWidth().padding(32.dp),
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        items(list, key = { it.id }) { m ->
            MatchCard(m, m.id == pinned) { MatchStore.togglePin(m.id) }
        }
    }
}

@Composable
private fun WidgetCard(running: Boolean, onToggle: (Boolean) -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape)
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, OrangeBrush, shape)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("Floating score widget", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                if (running) "Showing above other apps. Tap ★ on a match to pin it."
                else "Turn on to keep the score above all apps.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(checked = running, onCheckedChange = onToggle)
    }
}

@Composable
fun TeamLogo(url: String, name: String, size: Dp) {
    var bmp by remember(url) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(url) { bmp = ImageLoader.load(url) }
    Box(
        Modifier.size(size).clip(CircleShape).background(Color(0x22FFFFFF)),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(b.asImageBitmap(), name, Modifier.fillMaxSize().padding(6.dp))
        } else {
            Text(name.take(1).uppercase(), fontWeight = FontWeight.Bold, color = Orange)
        }
    }
}

@Composable
private fun TeamColumn(name: String, logo: String, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        TeamLogo(logo, name, 56.dp)
        Spacer(Modifier.height(6.dp))
        Text(
            name, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis,
            fontWeight = FontWeight.SemiBold, fontSize = 14.sp
        )
    }
}

@Composable
fun MatchCard(m: Match, pinned: Boolean, onPin: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(24.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape)
            .background(MaterialTheme.colorScheme.surface)
            .border(1.5.dp, OrangeBrush, shape)
            .clickable { open = !open }
            .padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "🏆  ${m.league.uppercase()}", modifier = Modifier.weight(1f),
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.Bold, fontSize = 13.sp
            )
            IconButton(onClick = onPin, modifier = Modifier.size(40.dp)) {
                Icon(
                    Icons.Filled.Star, "Pin to widget",
                    tint = if (pinned) Color(0xFFFFC107) else MaterialTheme.colorScheme.outline
                )
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(end = 8.dp, top = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TeamColumn(m.home, m.homeLogo, Modifier.weight(1f))
            Column(
                Modifier.widthIn(min = 92.dp).padding(horizontal = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (m.isUpcoming) {
                    Text(m.timeText, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF3FA9FF))
                    Text(
                        m.dateText, fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Text("${m.homeScore} - ${m.awayScore}", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
            TeamColumn(m.away, m.awayLogo, Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth().padding(end = 8.dp), contentAlignment = Alignment.Center) {
            StatusPill(m)
        }
        AnimatedVisibility(open) {
            Column(Modifier.padding(top = 12.dp, end = 8.dp)) {
                if (m.events.isEmpty()) Text("No events yet", style = MaterialTheme.typography.bodySmall)
                m.events.reversed().forEach {
                    Text(
                        "${it.icon}  ${it.minute}'  ${it.player} · ${it.team}",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun StatusPill(m: Match) {
    val t = rememberInfiniteTransition(label = "pulse")
    val a by t.animateFloat(
        0.25f, 1f, infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "alpha"
    )
    Row(
        Modifier
            .background(
                if (m.isLive) Color(0x33E53935) else MaterialTheme.colorScheme.surfaceVariant,
                RoundedCornerShape(50)
            )
            .padding(horizontal = 18.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (m.isLive) {
            Box(Modifier.size(8.dp).alpha(a).background(Color(0xFFE53935), CircleShape))
            Spacer(Modifier.width(6.dp))
        }
        Text(
            if (m.isUpcoming) m.startsIn() else m.clock,
            fontWeight = FontWeight.Bold, fontSize = 13.sp
        )
    }
}

@Composable
fun SettingsScreen(prefs: Prefs, theme: Int, onTheme: (Int) -> Unit, apiKey: String, onKey: (String) -> Unit) {
    val ctx = LocalContext.current
    var keyText by remember { mutableStateOf(apiKey) }
    var opacity by remember { mutableStateOf(prefs.opacity.toFloat()) }
    var poll by remember { mutableIntStateOf(prefs.pollSec) }
    var notify by remember { mutableStateOf(prefs.notifyGoals) }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Live data (API-Football)", fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = keyText, onValueChange = { keyText = it },
            label = { Text("API key") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            supportingText = { Text("Free key: dashboard.api-football.com. Leave empty for demo mode.") }
        )
        Button(onClick = {
            prefs.apiKey = keyText
            onKey(keyText.trim())
            MatchStore.clear()
            MatchStore.refresh()
            MatchStore.loadToday(true)
            Toast.makeText(ctx, "Saved ✓", Toast.LENGTH_SHORT).show()
        }) { Text("Save & refresh") }

        Spacer(Modifier.height(12.dp))
        Text("Theme", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("System", "Light", "Dark").forEachIndexed { i, s ->
                FilterChip(selected = theme == i, onClick = { onTheme(i) }, label = { Text(s) })
            }
        }

        Spacer(Modifier.height(12.dp))
        Text("Widget opacity: ${opacity.toInt()}%", fontWeight = FontWeight.Bold)
        Slider(value = opacity, onValueChange = { opacity = it; prefs.opacity = it.toInt() }, valueRange = 30f..100f)

        Spacer(Modifier.height(12.dp))
        Text("Update every (real API)", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(15, 30, 60).forEach { s ->
                FilterChip(selected = poll == s, onClick = { poll = s; prefs.pollSec = s }, label = { Text("${s}s") })
            }
        }
        Text(
            "Longer interval = less battery and fewer API calls (free plan: 100 requests/day).",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Goal notifications", fontWeight = FontWeight.Bold)
                Text("Get an alert with scorer and minute.", style = MaterialTheme.typography.bodySmall)
            }
            Switch(checked = notify, onCheckedChange = { notify = it; prefs.notifyGoals = it })
        }
    }
}
